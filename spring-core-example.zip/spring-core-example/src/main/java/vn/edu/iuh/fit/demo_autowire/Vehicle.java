package vn.edu.iuh.fit.demo_autowire;

import org.springframework.stereotype.Component;

@Component
public interface Vehicle {
    void run();
}
